package JavaBasicsProject;

public class E1 {
    public static void main(String[] args) {
        int [] temp = {78,55,88,70,50};
        int min = temp[0];
        int max = temp[0];

        for(int temperatures :temp){
            if(temperatures > max) {
                max = temperatures;
            }
            if(temperatures < min) {
                min = temperatures;
            }
        }

        System.out.println(min + " is the lowest temperature of the week");
        System.out.println(max + " is the highest temperature of the week");
    }
}
