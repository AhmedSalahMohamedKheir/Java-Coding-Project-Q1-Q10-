package JavaBasicsProject;

public class E10 {
    public static void main(String[] args) {
        String [] name = {"John", "John","Ahmed"};

        for(String names:name){
            if(names.equals("John")){
                System.out.println(names);
            }
        }
    }
}
