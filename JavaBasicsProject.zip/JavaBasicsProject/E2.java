package JavaBasicsProject;

public class E2 {
    public static void main(String[] args) {
        int[] num = {1, 10, 11, 23, 45};
        int sum = 0;
        for (int numbers : num) {
            sum = sum + numbers;
        }
        System.out.println(sum);
    }
}
