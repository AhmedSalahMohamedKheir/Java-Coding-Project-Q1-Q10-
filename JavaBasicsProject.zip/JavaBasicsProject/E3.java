package JavaBasicsProject;

public class E3 {
    public static void main(String[] args) {

        int [][] num = {
                {1,2,3},
                {4,5,6},
                {7,8,9}
        };
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                if(num[i][j]%2==0){
                    System.out.println(num[i][j]+" ");
                }
            }
        }

    }
}
