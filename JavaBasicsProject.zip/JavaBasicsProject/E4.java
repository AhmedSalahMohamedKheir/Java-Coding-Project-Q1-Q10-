package JavaBasicsProject;

public class E4 {
    public static void main(String[] args) {
        int[][] num = {
                {1,2,4,5,6},
                {5,7,8,9,10},
                {13,78,29,13,14}
        };
        int sum = 0;
        int add=0;
        for(int i=0;i<3;i++){ //rows
            for(int j=0;j<5;j++){ //columns
                if(num[i][j]%2==0){
                    sum = sum + num[i][j];
                }if(num[i][j]%2==1){
                    add = add +num[i][j];
                }
            }
        }
        System.out.println("The sum of all even numbers is: "+sum);
        System.out.println("The sum of all odd numbers is: "+add);
    }
}