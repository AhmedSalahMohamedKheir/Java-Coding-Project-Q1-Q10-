package JavaBasicsProject;

public class E5 {
    public static void main(String[] args) {
        int a = 10;//30
        int b = 20; //20 //10
        a = a+b;
        b = a-b;
        a = a-b;

        System.out.println("new value a = "+a);
        System.out.println("new value b = "+b);

    }
}


