package JavaBasicsProject;

public class E8 {
    public static void main(String[] args) {

        int[] num = {1, 10, 16, 18, 20, 99, 104};
        int min = num[0];
        int max = num[0];

        for (int numbers : num) {
            if (numbers > max) {
                max = numbers;
            }

            if (numbers < min) {
                min = numbers;
            }
        }
        System.out.println("The largest Number in the array is " + max);
        System.out.println("The smallest Number in the array is " + min);

    }
}
