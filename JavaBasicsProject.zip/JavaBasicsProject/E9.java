package JavaBasicsProject;
public class E9 {
    public static void main(String[] args) {
        int[] num = {1, 5, 6, 9, 10};
        int max = num[0];
        int secondMax = num[0];

        for (int numbers : num) {
            if (numbers > max) {
                secondMax = max;
                max = numbers;
            } else if (numbers > secondMax && numbers != max) {
                secondMax = numbers;
            }
        }
        System.out.println(secondMax);
    }
}